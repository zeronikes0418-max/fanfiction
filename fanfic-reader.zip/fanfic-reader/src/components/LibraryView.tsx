"use client";

import type { WorkMeta } from "@/types";
import { MAX_RECENT } from "@/lib/storage";
import { timeAgo } from "@/lib/text";

interface Props {
  works: WorkMeta[];
  onOpen: (meta: WorkMeta) => void;
  onDelete: (id: string) => void;
  onPickFile: () => void;
  onOpenImport: () => void;
}

/** 홈 화면: 최상단에 [최근 읽은 작품] 대시보드, 그 아래에 새 글 불러오기 */
export default function LibraryView({ works, onOpen, onDelete, onPickFile, onOpenImport }: Props) {
  return (
    <div className="mx-auto min-h-screen w-full max-w-2xl px-4 pb-24 pt-[calc(env(safe-area-inset-top)+28px)]">
      <header className="mb-8">
        <h1 className="text-2xl font-bold tracking-tight">팬픽 리더</h1>
        <p className="mt-1 text-sm text-reader-muted">
          .txt 파일이나 복사한 글을 불러오면, 읽던 위치부터 이어서 읽을 수 있어요.
        </p>
      </header>

      <section aria-labelledby="recent-title" className="mb-10">
        <div className="mb-3 flex items-baseline justify-between">
          <h2 id="recent-title" className="text-base font-bold">
            최근 읽은 작품
          </h2>
          <span className="text-xs text-reader-muted">
            {works.length} / {MAX_RECENT}
          </span>
        </div>

        {works.length === 0 ? (
          <p className="rounded-2xl border border-dashed border-reader-border p-6 text-center text-sm text-reader-muted">
            아직 읽은 작품이 없어요. 아래에서 첫 작품을 불러와 보세요.
          </p>
        ) : (
          <ul className="space-y-3">
            {works.map((w) => (
              <li
                key={w.id}
                className="flex items-stretch overflow-hidden rounded-2xl border border-reader-border bg-reader-ui"
              >
                <button
                  type="button"
                  onClick={() => onOpen(w)}
                  className="flex min-w-0 flex-1 flex-col gap-2.5 p-4 text-left transition-colors hover:bg-reader-hover active:bg-reader-hover"
                >
                  <span className="truncate text-base font-semibold">{w.title}</span>
                  <span
                    className="block h-1.5 w-full overflow-hidden rounded-full bg-reader-border"
                    role="progressbar"
                    aria-valuenow={Math.round(w.scrollPercent)}
                    aria-valuemin={0}
                    aria-valuemax={100}
                    aria-label="읽기 진행률"
                  >
                    <span
                      className="block h-full rounded-full bg-reader-accent"
                      style={{ width: `${w.scrollPercent}%` }}
                    />
                  </span>
                  <span className="flex items-center justify-between text-xs text-reader-muted">
                    <span>
                      {Math.round(w.scrollPercent)}% 읽음 · {w.length.toLocaleString()}자
                    </span>
                    <span>{timeAgo(w.lastReadAt)}</span>
                  </span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    if (window.confirm(`'${w.title}'을(를) 목록에서 삭제할까요?`)) onDelete(w.id);
                  }}
                  aria-label={`${w.title} 삭제`}
                  className="w-14 shrink-0 border-l border-reader-border text-lg text-reader-muted transition-colors hover:bg-reader-hover hover:text-red-500"
                >
                  🗑
                </button>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section aria-labelledby="add-title">
        <h2 id="add-title" className="mb-3 text-base font-bold">
          새 작품 불러오기
        </h2>
        <div className="rounded-2xl border-2 border-dashed border-reader-border p-6 text-center">
          <p className="mb-4 text-sm text-reader-muted">.txt 파일을 이 화면에 끌어다 놓아도 돼요.</p>
          <div className="flex flex-col gap-2 sm:flex-row sm:justify-center">
            <button
              type="button"
              onClick={onPickFile}
              className="h-12 rounded-xl bg-reader-accent px-6 text-sm font-bold text-reader-accentfg"
            >
              📂 .txt 파일 열기
            </button>
            <button
              type="button"
              onClick={onOpenImport}
              className="h-12 rounded-xl border border-reader-border px-6 text-sm font-medium hover:bg-reader-hover"
            >
              📋 텍스트 붙여넣기
            </button>
          </div>
        </div>
        <p className="mt-4 text-xs leading-relaxed text-reader-muted">
          읽는 중에는 화면을 한 번 탭하면 메뉴가 나타나요. 데스크톱에서는 마우스를 위쪽에 올리거나 Ctrl+F로 검색할 수
          있어요.
        </p>
      </section>
    </div>
  );
}
