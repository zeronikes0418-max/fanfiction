"use client";

import type { CSSProperties, ReactNode } from "react";
import type { ReaderSettings } from "@/types";
import { FONT_STACKS, LETTER_SPACING, SETTING_LIMITS, THEME_LIST } from "@/lib/themes";

interface Props {
  settings: ReaderSettings;
  onChange: <K extends keyof ReaderSettings>(key: K, value: ReaderSettings[K]) => void;
  onReset: () => void;
  onClose: () => void;
}

const stepBtn =
  "h-9 w-9 shrink-0 rounded-lg border border-reader-border text-base font-medium text-reader-fg hover:bg-reader-hover active:bg-reader-hover";

export default function SettingsPanel({ settings, onChange, onReset, onClose }: Props) {
  const L = SETTING_LIMITS;

  return (
    <section
      aria-label="읽기 설정"
      className="fixed inset-x-0 bottom-[calc(env(safe-area-inset-bottom)+76px)] z-40 max-h-[68vh] animate-slide-up overflow-y-auto rounded-t-3xl border border-reader-border bg-reader-ui p-4 shadow-2xl backdrop-blur-md md:inset-x-auto md:right-4 md:w-[380px] md:rounded-3xl"
    >
      <div className="mb-1 flex items-center justify-between">
        <h2 className="text-base font-bold">읽기 설정</h2>
        <button
          type="button"
          onClick={onClose}
          aria-label="설정 닫기"
          className="h-9 w-9 rounded-lg text-lg hover:bg-reader-hover"
        >
          ✕
        </button>
      </div>

      <Group label="테마">
        <div className="grid grid-cols-4 gap-2">
          {THEME_LIST.map((t) => {
            const selected = settings.theme === t.id;
            return (
              <button
                key={t.id}
                type="button"
                onClick={() => onChange("theme", t.id)}
                aria-pressed={selected}
                className={`flex flex-col items-center gap-1.5 rounded-xl p-1.5 text-xs font-medium transition-colors ${
                  selected ? "bg-reader-hover ring-2 ring-reader-accent" : "hover:bg-reader-hover"
                }`}
              >
                <span
                  className="flex h-11 w-full items-center justify-center rounded-lg border text-lg"
                  style={{ background: t.bg, color: t.fg, borderColor: t.border }}
                >
                  가
                </span>
                {t.label}
              </button>
            );
          })}
        </div>
      </Group>

      <Group label="글꼴">
        <Segmented
          value={settings.fontFamily}
          onChange={(v) => onChange("fontFamily", v)}
          options={[
            { value: "serif", label: "명조체 (바탕)", style: { fontFamily: FONT_STACKS.serif } },
            { value: "sans", label: "고딕체 (산스)", style: { fontFamily: FONT_STACKS.sans } },
          ]}
        />
      </Group>

      <StepSlider
        label="글자 크기"
        value={settings.fontSize}
        {...L.fontSize}
        format={(v) => `${v}px`}
        onChange={(v) => onChange("fontSize", v)}
      />
      <StepSlider
        label="줄간격"
        value={settings.lineHeight}
        {...L.lineHeight}
        format={(v) => `${v.toFixed(1)}배`}
        onChange={(v) => onChange("lineHeight", v)}
      />

      <Group label="자간">
        <Segmented
          value={settings.letterSpacing}
          onChange={(v) => onChange("letterSpacing", v)}
          options={(Object.keys(LETTER_SPACING) as Array<keyof typeof LETTER_SPACING>).map((k) => ({
            value: k,
            label: LETTER_SPACING[k].label,
          }))}
        />
      </Group>

      <div className="hidden md:block">
        <StepSlider
          label="좌우 여백"
          value={settings.sidePadding}
          {...L.sidePadding}
          format={(v) => `${v}%`}
          onChange={(v) => onChange("sidePadding", v)}
        />
      </div>
      <p className="py-2 text-xs text-reader-muted md:hidden">
        좌우 여백은 데스크톱에서 조절할 수 있어요. 모바일에서는 화면을 꽉 채워 보여 줘요.
      </p>

      <button
        type="button"
        onClick={onReset}
        className="mt-2 h-11 w-full rounded-xl border border-reader-border text-sm font-medium hover:bg-reader-hover"
      >
        기본값으로 되돌리기
      </button>
    </section>
  );
}

function Group({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="py-2">
      <p className="mb-1.5 text-sm font-medium">{label}</p>
      {children}
    </div>
  );
}

interface SegmentedProps<T extends string> {
  options: { value: T; label: string; style?: CSSProperties }[];
  value: T;
  onChange: (v: T) => void;
}

function Segmented<T extends string>({ options, value, onChange }: SegmentedProps<T>) {
  return (
    <div
      className="grid gap-1 rounded-xl bg-reader-hover p-1"
      style={{ gridTemplateColumns: `repeat(${options.length}, minmax(0, 1fr))` }}
    >
      {options.map((o) => (
        <button
          key={o.value}
          type="button"
          onClick={() => onChange(o.value)}
          aria-pressed={o.value === value}
          style={o.style}
          className={`min-h-[40px] rounded-lg px-2 text-sm font-medium transition-colors ${
            o.value === value ? "bg-reader-accent text-reader-accentfg shadow" : "text-reader-fg"
          }`}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

interface StepSliderProps {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  format: (v: number) => string;
  onChange: (v: number) => void;
}

function StepSlider({ label, value, min, max, step, format, onChange }: StepSliderProps) {
  const decimals = step < 1 ? 1 : 0;
  const apply = (v: number) => onChange(Number(Math.min(max, Math.max(min, v)).toFixed(decimals)));

  return (
    <div className="py-2">
      <div className="mb-1 flex items-center justify-between text-sm">
        <span className="font-medium">{label}</span>
        <span className="tabular-nums text-reader-muted">{format(value)}</span>
      </div>
      <div className="flex items-center gap-2">
        <button type="button" onClick={() => apply(value - step)} aria-label={`${label} 줄이기`} className={stepBtn}>
          −
        </button>
        <input
          type="range"
          min={min}
          max={max}
          step={step}
          value={value}
          aria-label={label}
          onChange={(e) => apply(Number(e.target.value))}
          className="h-8 min-w-0 flex-1 cursor-pointer accent-reader-accent"
        />
        <button type="button" onClick={() => apply(value + step)} aria-label={`${label} 키우기`} className={stepBtn}>
          +
        </button>
      </div>
    </div>
  );
}
