"use client";

import { memo, useEffect, useMemo, useState } from "react";
import type { ReactNode } from "react";
import { escapeRegExp } from "@/lib/text";

const INITIAL_CHUNKS = 8;
const BATCH_CHUNKS = 10;

interface ChunkProps {
  lines: string[];
  query: string;
  matchBase: number;
  activeIndex: number;
}

/** 문단 40줄 단위 블록. props가 같으면 리렌더되지 않아서 스크롤/설정 변경 때 부담이 없다. */
const Chunk = memo(function Chunk({ lines, query, matchBase, activeIndex }: ChunkProps) {
  const re = useMemo(
    () => (query ? new RegExp(`(${escapeRegExp(query)})`, "gi") : null),
    [query]
  );
  let counter = matchBase;

  return (
    <>
      {lines.map((line, i) => {
        if (line.length === 0) return <p key={i}>{"\u00A0"}</p>;
        if (!re) return <p key={i}>{line}</p>;

        const parts = line.split(re); // 홀수 인덱스가 일치 구간
        if (parts.length === 1) return <p key={i}>{line}</p>;

        const nodes: ReactNode[] = [];
        parts.forEach((part, j) => {
          if (j % 2 === 1) {
            const idx = counter++;
            nodes.push(
              <mark key={j} data-match={idx} className={idx === activeIndex ? "active" : undefined}>
                {part}
              </mark>
            );
          } else if (part) {
            nodes.push(part);
          }
        });
        return <p key={i}>{nodes}</p>;
      })}
    </>
  );
});

interface Props {
  chunks: string[][];
  chunkSize: number;
  query: string;
  /** matchPrefix[i] = i번째 문단 이전까지의 누적 일치 개수 (길이 = 문단 수 + 1) */
  matchPrefix: number[];
  activeIndex: number;
  onReady: () => void;
}

/**
 * 대용량 텍스트 점진 렌더링: 첫 화면분을 먼저 그리고, 나머지는 프레임마다 나눠서 마운트한다.
 * 전부 그려지면 onReady()를 호출 → 이어보기 위치 복원.
 */
function TextBody({ chunks, chunkSize, query, matchPrefix, activeIndex, onReady }: Props) {
  const [visible, setVisible] = useState(() => Math.min(chunks.length, INITIAL_CHUNKS));

  useEffect(() => {
    if (visible >= chunks.length) {
      onReady();
      return;
    }
    const id = window.requestAnimationFrame(() =>
      setVisible((v) => Math.min(chunks.length, v + BATCH_CHUNKS))
    );
    return () => window.cancelAnimationFrame(id);
  }, [visible, chunks.length, onReady]);

  const hasQuery = query.length > 0 && matchPrefix.length > 1;
  const paragraphCount = matchPrefix.length - 1;
  const items: ReactNode[] = [];

  for (let c = 0; c < visible; c++) {
    let base = 0;
    let active = -1;
    if (hasQuery) {
      base = matchPrefix[c * chunkSize] ?? 0;
      const end = matchPrefix[Math.min(paragraphCount, (c + 1) * chunkSize)] ?? base;
      if (activeIndex >= base && activeIndex < end) active = activeIndex;
    }
    items.push(
      <Chunk
        key={c}
        lines={chunks[c]}
        query={hasQuery ? query : ""}
        matchBase={base}
        activeIndex={active}
      />
    );
  }

  return <>{items}</>;
}

export default memo(TextBody);
