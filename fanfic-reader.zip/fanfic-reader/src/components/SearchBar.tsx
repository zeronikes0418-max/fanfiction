"use client";

import type { RefObject } from "react";

interface Props {
  query: string;
  onQueryChange: (v: string) => void;
  total: number;
  /** 1부터 시작하는 현재 위치 (일치 없으면 0) */
  position: number;
  onNext: () => void;
  onPrev: () => void;
  onClose: () => void;
  inputRef: RefObject<HTMLInputElement>;
}

export default function SearchBar({
  query,
  onQueryChange,
  total,
  position,
  onNext,
  onPrev,
  onClose,
  inputRef,
}: Props) {
  const hasQuery = query.trim().length > 0;
  const btn =
    "h-11 shrink-0 rounded-xl px-3 text-sm font-medium text-reader-fg transition-colors hover:bg-reader-hover active:bg-reader-hover disabled:opacity-40";

  return (
    <div className="fixed inset-x-0 bottom-[calc(env(safe-area-inset-bottom)+76px)] z-40 animate-slide-up px-3">
      <div className="mx-auto flex max-w-xl items-center gap-1 rounded-2xl border border-reader-border bg-reader-ui p-1.5 shadow-xl backdrop-blur-md">
        <input
          ref={inputRef}
          type="search"
          value={query}
          autoFocus
          enterKeyHint="search"
          placeholder="본문에서 단어 검색"
          aria-label="본문 검색"
          onChange={(e) => onQueryChange(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              e.preventDefault();
              if (e.shiftKey) onPrev();
              else onNext();
            }
          }}
          className="h-11 min-w-0 flex-1 rounded-xl bg-transparent px-3 text-base text-reader-fg outline-none placeholder:text-reader-muted"
        />
        <span className="shrink-0 px-1 text-xs tabular-nums text-reader-muted" aria-live="polite">
          {hasQuery ? (total === 0 ? "일치 없음" : `${position} / ${total}개`) : ""}
        </span>
        <button type="button" onClick={onPrev} disabled={total === 0} className={btn}>
          이전
        </button>
        <button type="button" onClick={onNext} disabled={total === 0} className={btn}>
          다음
        </button>
        <button type="button" onClick={onClose} aria-label="검색 닫기" className={btn}>
          ✕
        </button>
      </div>
    </div>
  );
}
