"use client";

import { useEffect, useRef, useState } from "react";

interface Props {
  onClose: () => void;
  onSubmit: (title: string, text: string) => void;
}

/** 삼성노트/메모장 등에서 복사한 글을 붙여넣어 바로 리더로 불러오는 팝업 */
export default function ImportModal({ onClose, onSubmit }: Props) {
  const titleRef = useRef<HTMLInputElement>(null);
  const textRef = useRef<HTMLTextAreaElement>(null);
  const [length, setLength] = useState(0);
  const [error, setError] = useState("");

  useEffect(() => {
    textRef.current?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  const submit = () => {
    const text = textRef.current?.value ?? "";
    if (!text.trim()) {
      setError("붙여넣은 내용이 없어요. 글을 붙여넣은 뒤 다시 눌러 주세요.");
      return;
    }
    onSubmit(titleRef.current?.value ?? "", text);
    onClose();
  };

  const pasteFromClipboard = async () => {
    try {
      const t = await navigator.clipboard.readText();
      if (textRef.current) {
        textRef.current.value = t;
        setLength(t.length);
        setError("");
      }
    } catch {
      setError("클립보드 권한이 없어요. 입력창을 길게 눌러 직접 붙여넣어 주세요.");
    }
  };

  return (
    <div
      className="fixed inset-0 z-[60] flex items-end justify-center bg-black/50 md:items-center md:p-6"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      role="dialog"
      aria-modal="true"
      aria-label="텍스트 가져오기"
    >
      <div className="flex max-h-[92vh] w-full animate-slide-up flex-col gap-3 rounded-t-3xl border border-reader-border bg-reader-bg p-4 pb-[calc(env(safe-area-inset-bottom)+16px)] text-reader-fg shadow-2xl md:max-w-2xl md:rounded-3xl md:pb-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold">텍스트 가져오기</h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="닫기"
            className="h-10 w-10 rounded-xl text-lg hover:bg-reader-hover"
          >
            ✕
          </button>
        </div>

        <p className="text-sm text-reader-muted">
          삼성노트나 메모장에서 복사한 글을 아래에 붙여넣으세요. 제목을 비워 두면 첫 줄을 제목으로 써요.
        </p>

        <input
          ref={titleRef}
          type="text"
          placeholder="제목 (선택)"
          aria-label="작품 제목"
          className="h-12 rounded-xl border border-reader-border bg-transparent px-3 text-base outline-none placeholder:text-reader-muted"
        />

        {/* 비제어 textarea: 수십만 자를 붙여넣어도 키 입력마다 리렌더되지 않는다 */}
        <textarea
          ref={textRef}
          rows={12}
          placeholder="여기에 글을 붙여넣으세요"
          aria-label="붙여넣을 본문"
          onInput={(e) => {
            setLength(e.currentTarget.value.length);
            setError("");
          }}
          className="min-h-[200px] flex-1 resize-none rounded-xl border border-reader-border bg-transparent p-3 text-base leading-relaxed outline-none placeholder:text-reader-muted"
        />

        <div className="flex items-center justify-between text-xs text-reader-muted">
          <span>{length.toLocaleString()}자</span>
          <button
            type="button"
            onClick={pasteFromClipboard}
            className="rounded-lg px-2 py-1 font-medium text-reader-accent hover:bg-reader-hover"
          >
            클립보드에서 붙여넣기
          </button>
        </div>

        {error && (
          <p role="alert" className="text-sm text-red-500">
            {error}
          </p>
        )}

        <div className="flex gap-2">
          <button
            type="button"
            onClick={onClose}
            className="h-12 flex-1 rounded-xl border border-reader-border text-sm font-medium hover:bg-reader-hover"
          >
            취소
          </button>
          <button
            type="button"
            onClick={submit}
            className="h-12 flex-[2] rounded-xl bg-reader-accent text-sm font-bold text-reader-accentfg"
          >
            리더로 불러오기
          </button>
        </div>
      </div>
    </div>
  );
}
