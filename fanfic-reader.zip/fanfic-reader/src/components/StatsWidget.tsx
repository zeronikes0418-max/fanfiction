"use client";

import { useState } from "react";
import { formatClock } from "@/lib/text";

interface Props {
  seconds: number;
  charsRead: number;
  progress: number;
  totalChars: number;
  idle: boolean;
  /** 상단 툴바가 보일 때 아래로 비켜준다 */
  offsetDown: boolean;
}

export default function StatsWidget({ seconds, charsRead, progress, totalChars, idle, offsetDown }: Props) {
  const [open, setOpen] = useState(false);

  const cpm = seconds >= 15 ? Math.round(charsRead / (seconds / 60)) : null;
  const remainChars = Math.max(0, totalChars * (1 - progress / 100));
  const remainMin = cpm && cpm > 0 ? Math.ceil(remainChars / cpm) : null;

  return (
    <div
      className="fixed right-3 z-30 flex flex-col items-end gap-2 transition-[top] duration-300"
      style={{ top: `calc(env(safe-area-inset-top) + ${offsetDown ? 66 : 12}px)` }}
    >
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-expanded={open}
        aria-label="독서 통계 보기"
        className="flex items-center gap-1.5 rounded-full border border-reader-border bg-reader-ui px-3 py-1.5 text-xs tabular-nums text-reader-fg opacity-60 shadow-sm backdrop-blur transition-opacity hover:opacity-100 focus-visible:opacity-100"
      >
        <span>⏱️ {formatClock(seconds)}</span>
        {cpm !== null && <span className="text-reader-muted">{cpm.toLocaleString()}자/분</span>}
        {idle && <span className="text-reader-muted">일시정지</span>}
      </button>

      {open && (
        <dl className="w-56 animate-fade-in space-y-1.5 rounded-2xl border border-reader-border bg-reader-ui p-3 text-xs shadow-xl backdrop-blur-md">
          <Row label="독서 시간" value={formatClock(seconds)} />
          <Row label="읽은 글자" value={`${Math.round(charsRead).toLocaleString()}자`} />
          <Row label="읽기 속도 (WPM)" value={cpm !== null ? `분당 ${cpm.toLocaleString()}자` : "측정 중…"} />
          <Row label="남은 시간" value={remainMin !== null ? `약 ${remainMin.toLocaleString()}분` : "측정 중…"} />
          <Row label="진행률" value={`${progress.toFixed(1)}%`} />
        </dl>
      )}
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <dt className="text-reader-muted">{label}</dt>
      <dd className="font-medium tabular-nums text-reader-fg">{value}</dd>
    </div>
  );
}
