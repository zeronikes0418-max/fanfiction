"use client";

import type { ReactNode } from "react";

interface Props {
  icon: ReactNode;
  label: string;
  onClick: () => void;
  active?: boolean;
  primary?: boolean;
  ariaLabel?: string;
}

/** 하단 툴바 버튼: 모바일은 세로(아이콘+라벨) 큰 터치 영역, 데스크톱은 가로 배치 */
export default function BarButton({ icon, label, onClick, active, primary, ariaLabel }: Props) {
  const tone = primary
    ? "bg-reader-accent text-reader-accentfg"
    : active
      ? "bg-reader-hover text-reader-accent"
      : "text-reader-fg hover:bg-reader-hover active:bg-reader-hover";

  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      aria-label={ariaLabel ?? label}
      className={`flex min-h-[52px] min-w-[48px] flex-col items-center justify-center gap-0.5 rounded-xl px-2.5 text-[11px] font-medium leading-tight transition-colors md:min-h-[44px] md:flex-row md:gap-2 md:px-4 md:text-sm ${tone}`}
    >
      <span className="text-lg leading-none md:text-base">{icon}</span>
      <span className="whitespace-nowrap">{label}</span>
    </button>
  );
}
