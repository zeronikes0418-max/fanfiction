export type ThemeId = "white" | "dark" | "sepia" | "midnight";
export type FontFamilyId = "serif" | "sans";
export type LetterSpacingId = "tight" | "normal" | "wide";

export interface ReaderSettings {
  theme: ThemeId;
  fontFamily: FontFamilyId;
  /** 14 ~ 32 (px) */
  fontSize: number;
  /** 1.4 ~ 2.5 (배) */
  lineHeight: number;
  letterSpacing: LetterSpacingId;
  /** 데스크톱 좌우 여백 (%) */
  sidePadding: number;
  /** 자동 스크롤 속도 단계 1 ~ 10 */
  autoScrollSpeed: number;
}

/** 목록/대시보드에 쓰는 가벼운 메타 정보 (본문은 별도 키에 저장) */
export interface WorkMeta {
  id: string;
  title: string;
  /** 본문 글자 수 */
  length: number;
  /** 읽던 위치 (0 ~ 100 %) */
  scrollPercent: number;
  lastReadAt: number;
}

export interface OpenWork {
  meta: WorkMeta;
  content: string;
  /** 같은 작품을 다시 열어도 뷰어를 새로 마운트하기 위한 번호 */
  seq: number;
}
