import type { ReaderSettings, ThemeId, WorkMeta } from "@/types";
import { DEFAULT_SETTINGS, SETTING_LIMITS, THEMES } from "./themes";

const PREFIX = "fanfic-reader:";
const INDEX_KEY = `${PREFIX}index`;
const SETTINGS_KEY = `${PREFIX}settings`;
const CURRENT_KEY = `${PREFIX}current`;
const contentKey = (id: string) => `${PREFIX}content:${id}`;

export const MAX_RECENT = 5;

function safeGet(key: string): string | null {
  if (typeof window === "undefined") return null;
  try {
    return window.localStorage.getItem(key);
  } catch {
    return null;
  }
}

function safeSet(key: string, value: string): boolean {
  if (typeof window === "undefined") return false;
  try {
    window.localStorage.setItem(key, value);
    return true;
  } catch {
    return false; // 용량 초과 / 사생활 보호 모드
  }
}

function safeRemove(key: string): void {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.removeItem(key);
  } catch {
    /* noop */
  }
}

function isWorkMeta(v: unknown): v is WorkMeta {
  if (typeof v !== "object" || v === null) return false;
  const o = v as Record<string, unknown>;
  return (
    typeof o.id === "string" &&
    typeof o.title === "string" &&
    typeof o.length === "number" &&
    typeof o.scrollPercent === "number" &&
    typeof o.lastReadAt === "number"
  );
}

/* ---------- 작품 목록 (메타) ---------- */

export function loadIndex(): WorkMeta[] {
  const raw = safeGet(INDEX_KEY);
  if (!raw) return [];
  try {
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed
      .filter(isWorkMeta)
      .sort((a, b) => b.lastReadAt - a.lastReadAt)
      .slice(0, MAX_RECENT);
  } catch {
    return [];
  }
}

export function saveIndex(list: WorkMeta[]): boolean {
  return safeSet(INDEX_KEY, JSON.stringify(list));
}

export function loadContent(id: string): string | null {
  return safeGet(contentKey(id));
}

/**
 * 작품 저장: 본문은 작품별 키에 한 번만 쓰고, 읽던 위치는 작은 index 키만 갱신한다.
 * (스크롤마다 수 MB 본문을 다시 쓰지 않기 위함)
 * 최근 5개를 넘으면 가장 오래된 작품을 삭제. 용량이 부족하면 오래된 작품부터 지우며 재시도.
 */
export function saveWork(meta: WorkMeta, content: string): { stored: boolean; list: WorkMeta[] } {
  let list = loadIndex().filter((w) => w.id !== meta.id);
  list.unshift(meta);
  list.sort((a, b) => b.lastReadAt - a.lastReadAt);

  list.slice(MAX_RECENT).forEach((w) => safeRemove(contentKey(w.id)));
  list = list.slice(0, MAX_RECENT);

  let stored = safeSet(contentKey(meta.id), content);
  while (!stored) {
    const victim = [...list].reverse().find((w) => w.id !== meta.id);
    if (!victim) break;
    safeRemove(contentKey(victim.id));
    list = list.filter((w) => w.id !== victim.id);
    stored = safeSet(contentKey(meta.id), content);
  }
  if (!stored) list = list.filter((w) => w.id !== meta.id);

  saveIndex(list);
  return { stored, list };
}

export function updateProgress(id: string, percent: number): WorkMeta[] {
  const list = loadIndex();
  const i = list.findIndex((w) => w.id === id);
  if (i < 0) return list;
  list[i] = {
    ...list[i],
    scrollPercent: Math.min(100, Math.max(0, percent)),
    lastReadAt: Date.now(),
  };
  list.sort((a, b) => b.lastReadAt - a.lastReadAt);
  saveIndex(list);
  return list;
}

export function removeWork(id: string): WorkMeta[] {
  safeRemove(contentKey(id));
  const list = loadIndex().filter((w) => w.id !== id);
  saveIndex(list);
  if (loadCurrentId() === id) saveCurrentId(null);
  return list;
}

/* ---------- 현재 열람 중인 작품 ---------- */

export function loadCurrentId(): string | null {
  return safeGet(CURRENT_KEY);
}

export function saveCurrentId(id: string | null): void {
  if (id === null) safeRemove(CURRENT_KEY);
  else safeSet(CURRENT_KEY, id);
}

/* ---------- 설정 ---------- */

function clampNum(v: unknown, min: number, max: number, fallback: number, decimals: number): number {
  if (typeof v !== "number" || !Number.isFinite(v)) return fallback;
  return Number(Math.min(max, Math.max(min, v)).toFixed(decimals));
}

export function loadSettings(): ReaderSettings {
  const d = DEFAULT_SETTINGS;
  const raw = safeGet(SETTINGS_KEY);
  if (!raw) return { ...d };
  try {
    const p = JSON.parse(raw) as Partial<Record<keyof ReaderSettings, unknown>>;
    const L = SETTING_LIMITS;
    const theme =
      typeof p.theme === "string" && p.theme in THEMES ? (p.theme as ThemeId) : d.theme;
    return {
      theme,
      fontFamily: p.fontFamily === "sans" || p.fontFamily === "serif" ? p.fontFamily : d.fontFamily,
      fontSize: clampNum(p.fontSize, L.fontSize.min, L.fontSize.max, d.fontSize, 0),
      lineHeight: clampNum(p.lineHeight, L.lineHeight.min, L.lineHeight.max, d.lineHeight, 1),
      letterSpacing:
        p.letterSpacing === "tight" || p.letterSpacing === "normal" || p.letterSpacing === "wide"
          ? p.letterSpacing
          : d.letterSpacing,
      sidePadding: clampNum(p.sidePadding, L.sidePadding.min, L.sidePadding.max, d.sidePadding, 0),
      autoScrollSpeed: clampNum(
        p.autoScrollSpeed,
        L.autoScrollSpeed.min,
        L.autoScrollSpeed.max,
        d.autoScrollSpeed,
        0
      ),
    };
  } catch {
    return { ...d };
  }
}

export function saveSettings(s: ReaderSettings): void {
  safeSet(SETTINGS_KEY, JSON.stringify(s));
}
