import type { CSSProperties } from "react";
import type { FontFamilyId, LetterSpacingId, ReaderSettings, ThemeId } from "@/types";

export interface ThemeDef {
  id: ThemeId;
  label: string;
  bg: string;
  fg: string;
  ui: string;
  border: string;
  muted: string;
  accent: string;
  accentFg: string;
  hover: string;
  mark: string;
  markFg: string;
  markActive: string;
  markActiveFg: string;
}

export const THEMES: Record<ThemeId, ThemeDef> = {
  white: {
    id: "white",
    label: "화이트",
    bg: "#ffffff",
    fg: "#1f2328",
    ui: "rgba(255,255,255,0.95)",
    border: "#e5e7eb",
    muted: "#6b7280",
    accent: "#2563eb",
    accentFg: "#ffffff",
    hover: "rgba(0,0,0,0.06)",
    mark: "#fde68a",
    markFg: "#1f2328",
    markActive: "#f97316",
    markActiveFg: "#ffffff",
  },
  dark: {
    id: "dark",
    label: "다크",
    bg: "#18181b",
    fg: "#d4d4d8",
    ui: "rgba(39,39,42,0.96)",
    border: "#3f3f46",
    muted: "#a1a1aa",
    accent: "#60a5fa",
    accentFg: "#0b1220",
    hover: "rgba(255,255,255,0.08)",
    mark: "#854d0e",
    markFg: "#fef3c7",
    markActive: "#f97316",
    markActiveFg: "#111111",
  },
  sepia: {
    id: "sepia",
    label: "세피아",
    bg: "#f4ecd8",
    fg: "#5b4636",
    ui: "rgba(236,224,198,0.97)",
    border: "#d8c9a6",
    muted: "#8a7358",
    accent: "#a0522d",
    accentFg: "#ffffff",
    hover: "rgba(91,70,54,0.1)",
    mark: "#f2d58a",
    markFg: "#4a3728",
    markActive: "#d9822b",
    markActiveFg: "#ffffff",
  },
  midnight: {
    id: "midnight",
    label: "미드나잇",
    bg: "#000000",
    fg: "#b3b3b3",
    ui: "rgba(10,10,10,0.97)",
    border: "#1f1f1f",
    muted: "#7a7a7a",
    accent: "#8ab4f8",
    accentFg: "#000000",
    hover: "rgba(255,255,255,0.08)",
    mark: "#5c4400",
    markFg: "#ffe9a8",
    markActive: "#c2410c",
    markActiveFg: "#ffffff",
  },
};

export const THEME_LIST: ThemeDef[] = [THEMES.white, THEMES.dark, THEMES.sepia, THEMES.midnight];

/** 테마 → CSS 변수 (루트 요소 style에 주입) */
export function themeVars(t: ThemeDef): CSSProperties {
  return {
    "--r-bg": t.bg,
    "--r-fg": t.fg,
    "--r-ui": t.ui,
    "--r-border": t.border,
    "--r-muted": t.muted,
    "--r-accent": t.accent,
    "--r-accentfg": t.accentFg,
    "--r-hover": t.hover,
    "--r-mark": t.mark,
    "--r-markfg": t.markFg,
    "--r-markactive": t.markActive,
    "--r-markactivefg": t.markActiveFg,
  } as CSSProperties;
}

export const FONT_STACKS: Record<FontFamilyId, string> = {
  serif:
    '"RIDIBatang", "Noto Serif KR", "Nanum Myeongjo", "AppleMyungjo", "Batang", "Source Han Serif K", serif',
  sans: '"Pretendard Variable", Pretendard, "Noto Sans KR", "Apple SD Gothic Neo", "Malgun Gothic", sans-serif',
};

export const LETTER_SPACING: Record<LetterSpacingId, { label: string; value: string }> = {
  tight: { label: "좁게", value: "-0.03em" },
  normal: { label: "보통", value: "0em" },
  wide: { label: "넓게", value: "0.04em" },
};

export const SETTING_LIMITS = {
  fontSize: { min: 14, max: 32, step: 1 },
  lineHeight: { min: 1.4, max: 2.5, step: 0.1 },
  sidePadding: { min: 2, max: 40, step: 1 },
  autoScrollSpeed: { min: 1, max: 10, step: 1 },
} as const;

export const DEFAULT_SETTINGS: ReaderSettings = {
  theme: "white",
  fontFamily: "serif",
  fontSize: 18,
  lineHeight: 1.8,
  letterSpacing: "normal",
  sidePadding: 20,
  autoScrollSpeed: 3,
};
