import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "팬픽 리더",
  description: "팬픽/웹소설 전용 텍스트 리더. .txt 파일이나 붙여넣은 글을 이어서 읽어요.",
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
  themeColor: "#ffffff",
};

// 하이드레이션 전에 저장된 테마 배경색을 먼저 칠해서 깜빡임을 막는다. (themes.ts의 bg와 동일하게 유지)
const themeBootScript = `(function(){try{var s=JSON.parse(localStorage.getItem('fanfic-reader:settings')||'{}');var c={white:'#ffffff',dark:'#18181b',sepia:'#f4ecd8',midnight:'#000000'}[s.theme]||'#ffffff';document.documentElement.style.backgroundColor=c;}catch(e){}})();`;

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ko" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
        <link
          rel="stylesheet"
          href="https://fonts.googleapis.com/css2?family=Noto+Sans+KR:wght@400;500;700&family=Noto+Serif+KR:wght@400;600&display=swap"
        />
        <link
          rel="stylesheet"
          href="https://cdn.jsdelivr.net/gh/orioncactus/pretendard@v1.3.9/dist/web/variable/pretendardvariable-dynamic-subset.min.css"
        />
        <script dangerouslySetInnerHTML={{ __html: themeBootScript }} />
      </head>
      <body>{children}</body>
    </html>
  );
}
