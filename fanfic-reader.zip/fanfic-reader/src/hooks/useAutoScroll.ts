"use client";

import { useEffect, useRef } from "react";

/** 속도 단계(1~10) → px/초 */
export const autoScrollPxPerSec = (level: number) => level * 18;

/**
 * requestAnimationFrame 기반 자동 스크롤.
 * - 소수점 이동량을 누적해서 느린 속도에서도 끊기지 않게 한다.
 * - 사용자가 직접 휠/터치로 스크롤하는 동안에는 잠시 멈췄다가 이어간다.
 */
export function useAutoScroll(active: boolean, level: number, onEnd: () => void): void {
  const onEndRef = useRef(onEnd);
  const pausedUntil = useRef(0);

  useEffect(() => {
    onEndRef.current = onEnd;
  });

  useEffect(() => {
    if (!active) return;

    const pause = (ms: number) => {
      pausedUntil.current = Date.now() + ms;
    };
    const onWheel = () => pause(700);
    const onTouchStart = () => pause(60_000);
    const onTouchEnd = () => pause(900);

    window.addEventListener("wheel", onWheel, { passive: true });
    window.addEventListener("touchstart", onTouchStart, { passive: true });
    window.addEventListener("touchend", onTouchEnd, { passive: true });
    window.addEventListener("touchcancel", onTouchEnd, { passive: true });

    const pxPerSec = autoScrollPxPerSec(level);
    let raf = 0;
    let last = performance.now();
    let acc = 0;

    const tick = (now: number) => {
      const dt = Math.min(now - last, 100);
      last = now;

      if (Date.now() >= pausedUntil.current) {
        acc += (pxPerSec * dt) / 1000;
        const step = Math.floor(acc);
        if (step >= 1) {
          acc -= step;
          const max = document.documentElement.scrollHeight - window.innerHeight;
          if (window.scrollY >= max - 1) {
            onEndRef.current();
            return;
          }
          window.scrollBy({ top: step, behavior: "auto" });
        }
      }
      raf = window.requestAnimationFrame(tick);
    };
    raf = window.requestAnimationFrame(tick);

    return () => {
      window.cancelAnimationFrame(raf);
      window.removeEventListener("wheel", onWheel);
      window.removeEventListener("touchstart", onTouchStart);
      window.removeEventListener("touchend", onTouchEnd);
      window.removeEventListener("touchcancel", onTouchEnd);
    };
  }, [active, level]);
}
