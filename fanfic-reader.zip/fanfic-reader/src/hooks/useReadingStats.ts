"use client";

import { useCallback, useEffect, useRef, useState } from "react";

const IDLE_MS = 120_000;

/**
 * 독서 타이머 + 속도 통계.
 * - 탭이 보이고, 최근 2분 안에 조작이 있거나 자동 스크롤 중일 때만 시간이 흐른다.
 * - 읽은 글자 수는 "앞으로 진행한 스크롤 %"를 글자 수로 환산해 누적한다.
 *   (한 번에 크게 점프하는 이동 — 검색 이동, 이어보기 복원 — 은 제외)
 */
export function useReadingStats(enabled: boolean, totalChars: number, keepAlive: boolean) {
  const [seconds, setSeconds] = useState(0);
  const [charsRead, setCharsRead] = useState(0);
  const [idle, setIdle] = useState(false);

  const secRef = useRef(0);
  const charsRef = useRef(0);
  const lastPercent = useRef<number | null>(null);
  const ignoreUntil = useRef(0);
  const lastActivity = useRef(Date.now());
  const keepAliveRef = useRef(keepAlive);
  const totalRef = useRef(totalChars);

  useEffect(() => {
    keepAliveRef.current = keepAlive;
    totalRef.current = totalChars;
  });

  const reset = useCallback(() => {
    secRef.current = 0;
    charsRef.current = 0;
    lastPercent.current = null;
    ignoreUntil.current = 0;
    lastActivity.current = Date.now();
    setSeconds(0);
    setCharsRead(0);
    setIdle(false);
  }, []);

  const ignoreFor = useCallback((ms: number) => {
    ignoreUntil.current = Date.now() + ms;
  }, []);

  const onProgress = useCallback((percent: number) => {
    const prev = lastPercent.current;
    lastPercent.current = percent;
    if (prev === null || Date.now() < ignoreUntil.current) return;
    const added = ((percent - prev) / 100) * totalRef.current;
    if (added > 0 && added < 2500) charsRef.current += added;
  }, []);

  useEffect(() => {
    if (!enabled) return;

    const touch = () => {
      lastActivity.current = Date.now();
    };
    const events: Array<keyof WindowEventMap> = ["scroll", "pointerdown", "keydown", "touchstart", "wheel"];
    events.forEach((e) => window.addEventListener(e, touch, { passive: true }));

    const id = window.setInterval(() => {
      const visible = document.visibilityState === "visible";
      const active = keepAliveRef.current || Date.now() - lastActivity.current < IDLE_MS;
      if (visible && active) {
        secRef.current += 1;
        setSeconds(secRef.current);
        setCharsRead(charsRef.current);
        setIdle(false);
      } else {
        setIdle(true);
      }
    }, 1000);

    return () => {
      window.clearInterval(id);
      events.forEach((e) => window.removeEventListener(e, touch));
    };
  }, [enabled]);

  return { seconds, charsRead, idle, reset, ignoreFor, onProgress };
}
