import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        reader: {
          bg: "var(--r-bg)",
          fg: "var(--r-fg)",
          ui: "var(--r-ui)",
          border: "var(--r-border)",
          muted: "var(--r-muted)",
          accent: "var(--r-accent)",
          accentfg: "var(--r-accentfg)",
          hover: "var(--r-hover)",
        },
      },
      keyframes: {
        slideUp: {
          from: { transform: "translateY(16px)", opacity: "0" },
          to: { transform: "translateY(0)", opacity: "1" },
        },
        fadeIn: {
          from: { opacity: "0" },
          to: { opacity: "1" },
        },
      },
      animation: {
        "slide-up": "slideUp 0.22s ease-out",
        "fade-in": "fadeIn 0.2s ease-out",
      },
    },
  },
  plugins: [],
};

export default config;
